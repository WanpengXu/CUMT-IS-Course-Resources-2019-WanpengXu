function solve_a()
    func=@func_a;
    x_max_asterisk=golden_section(func,0,1,-1)
    title('func\_a=(sinx)^6tan(1-x)e^{30x}')
end