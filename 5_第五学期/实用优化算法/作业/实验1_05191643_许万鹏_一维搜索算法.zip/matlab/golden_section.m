function x_asterisk=golden_section(f,a,b,reverse)
    if (nargin<4)
        reverse=1;%默认求最小值
    end
    epsilon=1e-5;
    %画图
    x=a:epsilon:b;
    y=f(x);
    figure
    plot(x,y)
    hold on
    r=(sqrt(5)-1)/2;%0.618
    x1=a+(1-r)*(b-a);
    x2=a+r*(b-a);
    f1=reverse*f(x1);
    f2=reverse*f(x2);
    while abs(b-a)>=epsilon
        if f1<=f2
            b=x2;
            x2=x1;
            f2=f1;
            x1=a+(1-r)*(b-a);
            f1=reverse*f(x1);
        else
            a=x1;
            x1=x2;
            f1=f2;
            x2=a+r*(b-a);
            f2=reverse*f(x2);
        end
        x_asterisk=(a+b)/2;
        %描点
        y_asterisk=f(x_asterisk);
        plot(x_asterisk,y_asterisk,'ro','markersize',5)
        pause(0.10);
    end
    plot(x_asterisk,y_asterisk,'rp','markersize',10)
end