function fx=func_b(x)
    fx=exp(x)+exp(-x);
end