function fx=func_a(x)
    fx=sin(x).^6.*tan(1-x).*exp(30.*x);
end