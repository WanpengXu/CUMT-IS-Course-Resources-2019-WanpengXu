function solve_b()
    func=@func_b;
    x_min_asterisk=golden_section(func,-1,2)
    title('func\_b=e^x+e^{-x}')
end