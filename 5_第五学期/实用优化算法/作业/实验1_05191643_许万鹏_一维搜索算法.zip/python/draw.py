import numpy as np
import matplotlib.pyplot as plt

def draw(func,a,b,x_values):
    plt.style.use('ggplot')
    # plt.rcParams['font.sans-serif']=['Microsoft YaHei']
    epsilon=1e-5
    x=np.arange(a,b,epsilon)
    y=[]
    for _ in x:
        y.append(func(_))
    plt.plot(x,y,color='steelblue')
    
    y_values = []
    for x_value in x_values:
        y_value=func(x_value)
        y_values.append(y_value)
        plt.plot(x_value,y_value,'ro',markersize=2)
        plt.pause(0.01)
    # plt.plot(x_values,y_values,'ro',markersize=2)
    plt.plot(x_values[-1],y_values[-1],'r*',markersize=10)
    plt.xlabel('x')
    plt.ylabel('f(x)')
    plt.show()