from golden_section import *

def main():
    plt.title('func_a(x)=sin(x)^6*tan(1-x)*e^(30*x)')
    x_max_asterisk=golden_section(func_a,0,1,-1)
    print(f"x_max_asterisk={x_max_asterisk:.4f}")

if __name__=='__main__':
    main()