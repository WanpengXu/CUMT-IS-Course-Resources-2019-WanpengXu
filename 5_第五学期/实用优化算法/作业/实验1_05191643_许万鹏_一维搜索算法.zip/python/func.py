from math import *

def func_a(x):
    fx=sin(x)**6*tan(1-x)*exp(30*x)
    return fx

def func_b(x):
    fx=exp(x)+exp(-x)
    return fx