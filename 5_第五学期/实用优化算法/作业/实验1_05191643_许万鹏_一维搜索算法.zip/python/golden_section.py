from math import sqrt
from draw import *
from func import *

def golden_section(func,a,b,reverse=1):
    epsilon=1e-5
    a0,b0=a,b
    r=(sqrt(5)-1)/2
    x1,x2=a+(1-r)*(b-a),a+r*(b-a)
    f1,f2=reverse*func(x1),reverse*func(x2)
    x_values=[]
    while abs(b-a)>=epsilon:
        if f1<=f2:
            a,b=a,x2
            x1,x2=a+(1-r)*(b-a),x1
            f1,f2=reverse*func(x1),f1
        else:
            a,b=x1,b
            x1,x2=x2,x1+r*(b-a)
            f1,f2=f2,reverse*func(x2)
        x_asterisk=(a+b)/2
        x_values.append(x_asterisk)
    draw(func,a0,b0,x_values)
    return x_asterisk