from golden_section import *

def main():
    plt.title('func_b(x)=e^x+e^(-x)')
    x_min_asterisk=golden_section(func_b,-1,2)
    print(f"x_min_asterisk={x_min_asterisk:.4e}")

if __name__=='__main__':
    main()