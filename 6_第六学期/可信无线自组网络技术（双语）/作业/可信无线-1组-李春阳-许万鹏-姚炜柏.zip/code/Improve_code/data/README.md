# The sampled datasets used for the experiments in the sample code

**IoT_2020_b_0.01_fs.csv**: The sampled IoTID20 dataset  
**cic_0.01km.csv**: The sampled CICIDS2017 dataset
