
import numpy as np
import pandas as pd

df = pd.read_csv('./CICIDS2017.csv')
df

df.Label.value_counts()

lab_list = df.Label.unique().tolist()
lab_list

# for index, row in result.iterrows():
#     # if row.Label == lab_list[0]:
#     #     result.loc[index,'Label'] = 'BENIGN'
#     if row.Label == lab_list[1] or :
#         result.loc[index,'Label'] = 'DoS'
#     elif row.Label == lab_list[5] or row.Label == lab_list[6] or row.Label == lab_list[7]:
#         result.loc[index,'Label'] = 'WebAttack'
#     # elif row.Label == lab_list[6]:
#     #     result.loc[index,'Label'] = 'WebAttack'
#     # elif row.Label == lab_list[7]:
#     #     result.loc[index,'Label'] = 'WebAttack'
#     elif row.Label == lab_list[8] or row.Label == lab_list[9]:
#         result.loc[index,'Label'] = 'BruteForce'
#     # elif row.Label == lab_list[9]:
#     #     result.loc[index,'Label'] = 'BruteForce'
#     elif row.Label == lab_list[10] or row.Label == lab_list[11] or row.Label == lab_list[12] or row.Label == lab_list[13] or row.Label == lab_list[14]:
#         result.loc[index,'Label'] = 'DoS'
#     # elif row.Label == lab_list[11]:
#     #     result.loc[index,'Label'] = 'DoS'
#     # elif row.Label == lab_list[12]:
#     #     result.loc[index,'Label'] = 'DoS'
#     # elif row.Label == lab_list[13]:
#     #     result.loc[index,'Label'] = 'DoS'
#     # elif row.Label == lab_list[14]:
#     #     result.loc[index,'Label'] = 'DoS'

# for index, row in df.iterrows():
#     if index >10 :
#         break
#     print(row[77])
#     if row[77] == 'BENIGN':
#         row[77] = 'sad'
#     print(row[77])
print("start")
for index, row in df.iterrows():
    if row[77] == lab_list[1]:
        row[77] = 'DoS'
    elif row[77] == lab_list[5] or row[77] == lab_list[6] or row[77] == lab_list[7]:
        row[77] = 'WebAttack'
    elif row[77] == lab_list[8] or row[77] == lab_list[9]:
        row[77] = 'BruteForce'
    elif row[77] == lab_list[10] or row[77] == lab_list[11] or row[77] == lab_list[12] or row[77] == lab_list[13] or row[77] == lab_list[14]:
        row[77] = 'DoS'

print("end")
df.Label.value_counts()

df.to_csv('./data/CICIDS2017_1.csv',index=None)


