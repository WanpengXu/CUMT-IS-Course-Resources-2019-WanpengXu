# The sampled datasets used for the experiments in the sample code

**CICIDS2017_sample.csv**: The randomly sampled subset of CICIDS2017  
**CICIDS2017_sample_km.csv**: The subset of CICIDS2017 sampled by k-means clustering  
