#include "rate.h"
#include "ui_rate.h"
#include<QDebug>
#include<qmath.h>
rate::rate(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::rate)
{
    ui->setupUi(this);
    qbtg = new QButtonGroup(this);

    qbtg->addButton(ui->rbtn_blp);
    qbtg->addButton(ui->rbtn_bpp);

    qbtg->setId(ui->rbtn_blp, 0);
    qbtg->setId(ui->rbtn_bpp, 1);

    ui->rbtn_blp->setChecked(true);
    //connect( qbtg, SIGNAL(buttonToggled(int, bool), this, SLOT(on_bgGroup_toggled(int, bool))));
}

rate::~rate()
{
    delete ui;
}

void rate::on_pbtn_compute_clicked()
{
    int a = qbtg->checkedId();
    term=ui->loan_term->text().toInt();
    money=ui->loan_amount->text().toDouble()*10000;
    ratep=ui->loan_rate->text().toFloat()/100/12;
    switch(a)
    {
    case 0:
        //qDebug()<<'1';
        mrepay=money*ratep*qPow((1+ratep),term*12)
                /(qPow((1+ratep),term*12)-1);
        trepay=mrepay*12*term;
        tgross=trepay-money;
        ui->mon_repay->setText(QString::number(mrepay,'g'));
        ui->repay_total->setText(QString::number(trepay,'g'));
        ui->gross_total->setText(QString::number(tgross,'g'));
        break;
    case 1:
        //qDebug()<<'2';
        tgross=((money/(term*12)+money*ratep)+money/
                (term*12)*(1+ratep))/2*(term*12)-money;
        trepay=tgross+money;
        mrepay=trepay/(term*12);
        ui->mon_repay->setText(QString::number(mrepay,'g'));
        ui->repay_total->setText(QString::number(trepay,'g'));
        ui->gross_total->setText(QString::number(tgross,'g'));
        break;
    default:
        break;
    }
}

void rate::on_pbtn_recompute_clicked()
{
    term=money=ratep=mrepay=trepay=tgross=0;
    ui->loan_term->clear();
    ui->loan_amount->clear();
    ui->loan_rate->clear();
    ui->mon_repay->clear();
    ui->repay_total->clear();
    ui->gross_total->clear();
}

void rate::on_action_triggered()
{
    this->close();
    //ma.show();
}
