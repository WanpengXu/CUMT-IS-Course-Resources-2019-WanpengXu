#ifndef XYZ_H
#define XYZ_H

#include <QDialog>
#include <QButtonGroup>

namespace Ui {
class xyz;
}

class xyz : public QDialog
{
    Q_OBJECT

public:
    explicit xyz(QWidget *parent = nullptr);
    ~xyz();

private slots:
    void on_pbtn_r2rcompuse_clicked();

    void on_pbtn_rer2rcompuse_clicked();

private:
    Ui::xyz *ui;
    QButtonGroup* qbtg1,*qbtg2;
    char* srcstr;
};

#endif // XYZ_H
