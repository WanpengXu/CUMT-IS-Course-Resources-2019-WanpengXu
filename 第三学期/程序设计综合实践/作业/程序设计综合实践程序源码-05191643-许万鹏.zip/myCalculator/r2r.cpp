#include "r2r.h"
#include "ui_xyz.h"
#include <cstring>
#include <qDebug>
xyz::xyz(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::xyz)
{
    ui->setupUi(this);
    qbtg1 = new QButtonGroup(this);

    qbtg2 = new QButtonGroup(this);

    qbtg1->addButton(ui->rbtn1_2);
    qbtg1->addButton(ui->rbtn1_8);
    qbtg1->addButton(ui->rbtn1_10);
    qbtg1->addButton(ui->rbtn1_16);

    qbtg1->setId(ui->rbtn1_2,2);
    qbtg1->setId(ui->rbtn1_8,8);
    qbtg1->setId(ui->rbtn1_10,10);
    qbtg1->setId(ui->rbtn1_16,16);

    qbtg2->addButton(ui->rbtn2_2);
    qbtg2->addButton(ui->rbtn2_8);
    qbtg2->addButton(ui->rbtn2_10);
    qbtg2->addButton(ui->rbtn2_16);

    qbtg2->setId(ui->rbtn2_2,2);
    qbtg2->setId(ui->rbtn2_8,8);
    qbtg2->setId(ui->rbtn2_10,10);
    qbtg2->setId(ui->rbtn2_16,16);

    ui->le_2r->setAlignment(Qt::AlignRight);
    ui->le_r2->setAlignment(Qt::AlignRight);

    ui->rbtn1_10->setChecked(true);
    ui->rbtn2_2->setChecked(true);
}

xyz::~xyz()
{
    delete ui;
}

void xyz::on_pbtn_r2rcompuse_clicked()
{
    int rto=qbtg1->checkedId();
    QString srcstr0=ui->le_r2->text();
    QString srcstr;
    bool ok;
    switch (rto) {
    case 2:srcstr=QString::number(srcstr0.toInt(&ok,2));break;
    case 8:srcstr=QString::number(srcstr0.toInt(&ok,8));break;
    case 10:srcstr=QString::number(srcstr0.toInt(&ok,10));break;
    case 16:srcstr=QString::number(srcstr0.toInt(&ok,16));break;
    }
    int tor=qbtg2->checkedId();
    QString rststr;
    switch (tor) {
    case 2:rststr=QString::number(srcstr.toInt(),2);break;
    case 8:rststr=QString::number(srcstr.toInt(),8);break;
    case 10:rststr=QString::number(srcstr.toInt(),10);break;
    case 16:rststr=QString::number(srcstr.toInt(),16);break;
    }
    ui->le_2r->setText(rststr);
}

void xyz::on_pbtn_rer2rcompuse_clicked()
{
    ui->le_2r->clear();
    ui->le_r2->clear();
}
