#ifndef STANDWINDOW_H
#define STANDWINDOW_H

#include <QMainWindow>

namespace Ui {
class standwindow;
}

class standwindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit standwindow(QWidget *parent = nullptr);
    ~standwindow();

private:
    Ui::standwindow *ui;
};

#endif // STANDWINDOW_H
