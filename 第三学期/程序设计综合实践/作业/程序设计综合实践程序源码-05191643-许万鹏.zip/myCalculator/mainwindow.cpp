#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QtCore/qmath.h>
#include <QDebug>
#include <QGraphicsDropShadowEffect>
#include "cmleval.h"
/*
该版本已实现动态计算，下一步需要实现混合运算ok。下一步实现百分号、倒数、按键美化
缺少：百分号、倒数、混合运算ok
*/
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    num1=0;num2=0;result=0;
    flag=0;
    S="";Snum1="";Snum2="";Seval="";
    this->setFixedSize(this->width(),this->height());
    //ui->setupUi(this);
    //设置窗体透明
    //this->setAttribute(Qt::WA_TranslucentBackground, true);
    //设置无边框
    //this->setWindowFlags(Qt::Window | Qt::FramelessWindowHint);
    //实例阴影shadow
    //QGraphicsDropShadowEffect *shadow = new QGraphicsDropShadowEffect(this);
    //设置阴影距离
    //shadow->setOffset(0, 0);
    //设置阴影颜色
    //shadow->setColor(QColor("#444444"));
    //设置阴影圆角
    //shadow->setBlurRadius(30);
    //给嵌套QWidget设置阴影
    //ui->widget_bg->setGraphicsEffect(shadow);
    //给垂直布局器设置边距(此步很重要, 设置宽度为阴影的宽度)
    //ui->lay_bg->setMargin(24);

    ui->resultDisplay->setStyleSheet("background:transparent;border-width:0;border-style:outset");
    ui->txtDisplay->setStyleSheet("background:transparent;border-width:0;border-style:outset");
    ui->resultDisplay->setAlignment(Qt::AlignRight);
    ui->txtDisplay->setAlignment(Qt::AlignRight);
    ui->btn_equal->setStyleSheet("background-color: rgb(227,170,162);");
    ui->btn_point->setStyleSheet("background-color: rgb(252,252,252);");
    ui->btn_0->setStyleSheet("background-color: rgb(252,252,252);");
    ui->btn_1->setStyleSheet("background-color: rgb(252,252,252);");
    ui->btn_2->setStyleSheet("background-color: rgb(252,252,252);");
    ui->btn_3->setStyleSheet("background-color: rgb(252,252,252);");
    ui->btn_4->setStyleSheet("background-color: rgb(252,252,252);");
    ui->btn_5->setStyleSheet("background-color: rgb(252,252,252);");
    ui->btn_6->setStyleSheet("background-color: rgb(252,252,252);");
    ui->btn_7->setStyleSheet("background-color: rgb(252,252,252);");
    ui->btn_8->setStyleSheet("background-color: rgb(252,252,252);");
    ui->btn_9->setStyleSheet("background-color: rgb(252,252,252);");
    ui->btn_pos->setStyleSheet("background-color: rgb(252,252,252);");
    ui->btn_add->setStyleSheet("background-color: rgb(245,245,245);");
    ui->btn_sub->setStyleSheet("background-color: rgb(245,245,245);");
    ui->btn_multi->setStyleSheet("background-color: rgb(245,245,245);");
    ui->btn_div->setStyleSheet("background-color: rgb(245,245,245);");
    ui->btn_backspace->setStyleSheet("background-color: rgb(245,245,245);");
    ui->btn_clear->setStyleSheet("background-color: rgb(245,245,245);");
    ui->btn_clear_entry->setStyleSheet("background-color: rgb(245,245,245);");
    ui->btn_rtd->setStyleSheet("background-color: rgb(245,245,245);");
    ui->btn_dtr->setStyleSheet("background-color: rgb(245,245,245);");
    ui->btn_reciprocal->setStyleSheet("background-color: rgb(245,245,245);");
    ui->btn_square->setStyleSheet("background-color: rgb(245,245,245);");
    ui->btn_square_root->setStyleSheet("background-color: rgb(245,245,245);");
    ui->btn_leftbracket->setStyleSheet("background-color: rgb(245,245,245);");
    ui->btn_rightbracket->setStyleSheet("background-color: rgb(245,245,245);");
    ui->btn_sin->setStyleSheet("background-color: rgb(245,245,245);");
    ui->btn_cos->setStyleSheet("background-color: rgb(245,245,245);");
    ui->btn_ln->setStyleSheet("background-color: rgb(245,245,245);");
    ui->btn_log->setStyleSheet("background-color: rgb(245,245,245);");
    ui->btn_pi->setStyleSheet("background-color: rgb(245,245,245);");
    ui->btn_e->setStyleSheet("background-color: rgb(245,245,245);");
    ui->btn_tan->setStyleSheet("background-color: rgb(245,245,245);");
    ui->btn_abs->setStyleSheet("background-color: rgb(245,245,245);");
    ui->btn_asin->setStyleSheet("background-color: rgb(245,245,245);");
    ui->btn_acos->setStyleSheet("background-color: rgb(245,245,245);");
    ui->btn_atan->setStyleSheet("background-color: rgb(245,245,245);");
    ui->btn_ceil->setStyleSheet("background-color: rgb(245,245,245);");
    ui->btn_floor->setStyleSheet("background-color: rgb(245,245,245);");
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_btn_0_clicked()
{
    S+='0';
    Seval+="~0";
    ui->txtDisplay->setText(S);
    /*QString S1="~1~2~+~3~*~5";
    S1.remove(0,1);
    QStringList Sl1=S1.split('~');

    cout<<cmleval1(Sl1);
    */
}

void MainWindow::on_btn_1_clicked()
{
    S+='1';
    Seval+="~1";
    ui->txtDisplay->setText(S);
}

void MainWindow::on_btn_2_clicked()
{
    S+='2';
    Seval+="~2";
    ui->txtDisplay->setText(S);
}

void MainWindow::on_btn_3_clicked()
{
    S+='3';
    Seval+="~3";
    ui->txtDisplay->setText(S);
}

void MainWindow::on_btn_4_clicked()
{
    S+='4';
    Seval+="~4";
    ui->txtDisplay->setText(S);
}

void MainWindow::on_btn_5_clicked()
{
    S+='5';
    Seval+="~5";
    ui->txtDisplay->setText(S);
}

void MainWindow::on_btn_6_clicked()
{
    S+='6';
    Seval+="~6";
    ui->txtDisplay->setText(S);
}

void MainWindow::on_btn_7_clicked()
{
    S+='7';
    Seval+="~7";
    ui->txtDisplay->setText(S);
}

void MainWindow::on_btn_8_clicked()
{
    S+='8';
    Seval+="~8";
    ui->txtDisplay->setText(S);
}

void MainWindow::on_btn_9_clicked()
{
    S+='9';
    Seval+="~9";
    ui->txtDisplay->setText(S);
}

void MainWindow::on_btn_point_clicked()
{
    S+=".";
    Seval+="~.";
    ui->txtDisplay->setText(S);
}

void MainWindow::on_btn_add_clicked()
{
    S+='+';
    Seval+="~+";
    ui->txtDisplay->setText(S);
}

void MainWindow::on_btn_sub_clicked()
{
    S+='-';
    Seval+="~-";
    ui->txtDisplay->setText(S);
}

void MainWindow::on_btn_multi_clicked()
{
    S+="×";
    Seval+="~*";
    ui->txtDisplay->setText(S);
}

void MainWindow::on_btn_div_clicked()
{
    S+="÷";
    Seval+="~/";
    ui->txtDisplay->setText(S);
}

void MainWindow::on_btn_equal_clicked()
{
    S+="=";
    Seval.remove(0,1);
    Sl=Seval.split('~');
    Snum1=QString::number(cmleval1(Sl),'g');
    ui->resultDisplay->setText(Snum1);
    ui->txtDisplay->setText(S);
}

void MainWindow::on_btn_backspace_clicked()
{
    S=S.left(S.length()-1);
    Seval=Seval.left(Seval.length()-2);
    ui->txtDisplay->setText(S);
}

void MainWindow::on_btn_clear_clicked()
{
    S.clear();
    Seval.clear();
    ui->txtDisplay->clear();
    ui->resultDisplay->clear();
}

void MainWindow::on_btn_clear_entry_clicked()
{
    S.clear();
    Seval.clear();
    ui->txtDisplay->clear();
    ui->resultDisplay->clear();
}

void MainWindow::on_btn_reciprocal_clicked()
{
    S+="1/(";
    flag='r';
    Seval+="~(";
    ui->txtDisplay->setText(S);
}

void MainWindow::on_btn_square_clicked()
{
    S+="^";
    Seval+="~^";
    ui->txtDisplay->setText(S);
}

void MainWindow::on_btn_sqrt_clicked()
{
    S+="^";
    Seval+="~^~0~.~5";
    ui->txtDisplay->setText(S);
}

void MainWindow::on_btn_leftbracket_clicked()
{
    S+="(";
    Seval+="~(";
    ui->txtDisplay->setText(S);
}

void MainWindow::on_btn_rightbracket_clicked()
{
    switch(flag)
    {
    case 0 :
        S+=")";
        Seval+="~)";
        break;

    case 's' :
        S+=")";
        Seval+="~)~s";
        break;
    case 'c' :
        S+=")";
        Seval+="~)~c";
        break;
    case 'l' :
        S+=")";
        Seval+="~)~l";
        break;
    case 'g' :
        S+=")";
        Seval+="~)~g";
        break;
    case 't' :
        S+=")";
        Seval+="~)~t";
        break;
    case 'a' :
        S+=")";
        Seval+="~)~a";
        break;
    case 'u' :
        S+=")";
        Seval+="~)~u";
        break;
    case 'd' :
        S+=")";
        Seval+="~)~d";
        break;
    case 'i' :
        S+=")";
        Seval+="~)~i";
        break;
    case 'j' :
        S+=")";
        Seval+="~)~j";
        break;
    case 'k' :
        S+=")";
        Seval+="~)~k";
        break;
    case 'm' :
        S+=")";
        Seval+="~)~m";
        break;
    case 'n' :
        S+=")";
        Seval+="~)~n";
        break;
    case 'r' :
        S+=")";
        Seval+="~)~r";
        break;
    case 'w' :
        S+=")";
        Seval+="~)~w";
        break;
    case 'p' :
        S+=")";
        Seval+="~)~p";
        break;
    }
    flag=0;
    ui->txtDisplay->setText(S);
}

void MainWindow::on_btn_sin_clicked()
{
    S+="sin(";
    flag='s';
    Seval+="~(";
    ui->txtDisplay->setText(S);
}

void MainWindow::on_btn_cos_clicked()
{
    S+="cos(";
    flag='c';
    Seval+="~(";
    ui->txtDisplay->setText(S);
}

void MainWindow::on_btn_ln_clicked()
{
    S+="ln(";
    flag='l';
    Seval+="~(";
    ui->txtDisplay->setText(S);
}

void MainWindow::on_btn_log_clicked()
{
    S+="log(";
    flag='g';
    Seval+="~(";
    ui->txtDisplay->setText(S);
}

void MainWindow::on_btn_pi_clicked()//用不了
{
    S+="π";
    Seval+="~3~.~1~4~1~5~9~2~6";
    ui->txtDisplay->setText(S);
}

void MainWindow::on_btn_e_clicked()
{
    S+="e";
    Seval+="~2~.~7~1~8~2~8~1~8~2~8";
    ui->txtDisplay->setText(S);
}

void MainWindow::on_btn_tan_clicked()
{
    S+="tan(";
    flag='t';
    Seval+="~(";
    ui->txtDisplay->setText(S);
}

void MainWindow::on_btn_abs_clicked()
{
    S+="abs(";
    flag='a';
    Seval+="~(";
    ui->txtDisplay->setText(S);
}

void MainWindow::on_btn_ceil_clicked()
{
    S+="ceil(";
    flag='u';
    Seval+="~(";
    ui->txtDisplay->setText(S);
}

void MainWindow::on_btn_floor_clicked()
{
    S+="floor(";
    flag='d';
    Seval+="~(";
    ui->txtDisplay->setText(S);
}

void MainWindow::on_btn_asin_clicked()
{
    S+="asin(";
    flag='i';
    Seval+="~(";
    ui->txtDisplay->setText(S);
}

void MainWindow::on_btn_acos_clicked()
{
    S+="acos(";
    flag='j';
    Seval+="~(";
    ui->txtDisplay->setText(S);
}

void MainWindow::on_btn_atan_clicked()
{
    S+="atan(";
    flag='k';
    Seval+="~(";
    ui->txtDisplay->setText(S);
}

void MainWindow::on_btn_rtd_clicked()
{
    S+="RtoD(";
    flag='m';
    Seval+="~(";
    ui->txtDisplay->setText(S);
}

void MainWindow::on_btn_dtr_clicked()
{
    S+="DtoR(";
    flag='n';
    Seval+="~(";
    ui->txtDisplay->setText(S);
}

void MainWindow::on_btn_square_root_clicked()
{
    S+="sqrt(";
    flag='w';
    Seval+="~(";
    ui->txtDisplay->setText(S);
}

void MainWindow::on_act_about_triggered()
{
    ab.show();
}

void MainWindow::on_act_rate_triggered()
{

    //this->showMinimized();//this->close();
    ra.show();
}

void MainWindow::on_act_xyz_triggered()
{
    xy.show();
}

void MainWindow::on_btn_pos_clicked()
{
    S+="-(";
    flag='p';
    Seval+="~(";
    ui->txtDisplay->setText(S);
}
