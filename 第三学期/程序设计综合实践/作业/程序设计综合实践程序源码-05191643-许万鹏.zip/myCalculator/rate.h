#ifndef RATE_H
#define RATE_H

#include <QButtonGroup>
//#include "mainwindow.h"
#include <QMainWindow>

namespace Ui {
class rate;
}

class rate : public QMainWindow
{
    Q_OBJECT

public:
    explicit rate(QWidget *parent = nullptr);
    ~rate();

private slots:
    void on_pbtn_compute_clicked();

    void on_pbtn_recompute_clicked();

    void on_action_triggered();

private:
    Ui::rate *ui;
    //MainWindow ma;
    QButtonGroup* qbtg;
    int term;
    double money;
    float ratep;
    double mrepay;
    double tgross;
    double trepay;
};

#endif // RATE_H
