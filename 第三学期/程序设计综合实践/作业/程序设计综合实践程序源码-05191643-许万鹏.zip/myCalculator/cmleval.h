#ifndef CMLEVAL_H
#define CMLEVAL_H
#include<iostream>
#include<stack>
#include<string>
#include<vector>
#include<sstream>
#include<cmath>
#include<QApplication>
#include<qmath.h>
#define max 100

using namespace std;

double RtoD(double rad)
{
    double dpr=45.0/atan(1.0);
    return rad*dpr;
}
double DtoR(double deg)
{
    double rpd=atan(1.0)/45.0;
    return deg*rpd;
}
double rec(double x)
{
    return 1.0/x;
}
double plusorminus(double x)
{
    return 0-x;
}
//对二目操作符进行优先级的量化转变
int getPri(char c)
{
    switch (c) {
    case '+':
        return 1; break;
    case '-':
        return 1; break;//‘+’和‘-’的优先级为最低级1
    case '*':
        return 2; break;
    case '/':
        return 2; break;//‘*’和‘/’的优先级为中级2
    case '^':
        return 3; break;//‘^’的优先级最高，为3
    default:
        return 0; break;
    }
}
//判断字符是否是二目操作符
int isOpr(char c)
{
    switch (c){
    case '+':
    case '-':
    case '*':
    case '/':
    case '^':
        return 1; break;
    default:
        return 0; break;
    }
}
//判断字符是否是数字或者是未知量
int isNum(char c)
{
    switch (c){
    case '0':
    case '1':
    case '2':
    case '3':
    case '4':
    case '5':
    case '6':
    case '7':
    case '8':
    case '9':
    case '.':
        return 1; break;
    default:
        return 0; break;
    }
}
//判断字符是否代表特殊函数，为了程序简单，取特殊函数的某个字母代替该函数（此类函数均为单目运算）
int isChar(char c)
{
    switch (c){
    case 's'://sin函数
    case 'c'://cos函数
    case 't'://tan函数
    case 'a'://abs函数
    case 'q'://sqrt函数
    case 'l'://ln函数
    case 'g'://log10函数
    case 'u'://ceil函数
    case 'd'://floor函数
    case 'i'://asin函数
    case 'j'://acos函数
    case 'k'://atan函数
    case 'm'://RtoD函数
    case 'n'://DtoR函数
    case 'r'://rec函数
    case 'w'://sqrt函数
    case 'p'://plusorminus函数
        return 1; break;
    default:
        return 0; break;
    }
}

//中缀表达式改写成后缀表达式
void getPostFix(char *in, char *post)
{
    stack<char> st;//创建一个字符类的栈，用于存放操作符
    st.push('@');//存一个@进栈底，方便于最后判断栈里的操作符是否已经全部出栈
    int i = 0;
    int j = 0;
    while (in[i] != '#')//'#'为字符数组的最后一个元素
    {
        char ch = in[i];
        if (isNum(ch))//判断是否是数字或者未知量，若是则把其放进后缀字符数组
        {
            post[j++] = ch;
            i++;
        }
        else if (isChar(ch))//判断字符是否是常见（单目运算）函数的缩写，若是则将函数后面的数放进后缀字符数组，再将函数名缩写放进后缀数组
        {
            i++;
            char ch1 = in[i];
            while (isNum(ch1))
            {
                post[j++] = ch1;
                i++;
                ch1 = in[i];
            }//把函数后面的数输进后缀字符数组
            post[j++] = ' ';//用空格分开数和函数名
            post[j++] = ch;	//将函数名的缩写放进后缀表达式的数组
        }
        else   //若字符是二目操作符或者是括号，则做以下操作
        {
            post[j++] = ' ';//用空格隔开操作符前后的数，便于后续读取
            if (ch == '(')//如果字符是'('，则将字符进栈
            {
                st.push(ch);

            }
            else if (ch == ')')  //若字符是')'，则将栈中的字符输进后缀表达式的字符数组，直至遇到'('
            {
                ch = st.top();
                while (ch != '(')
                {
                    post[j++] = ch;
                    st.pop();
                    ch = st.top();
                }
                st.pop(); //将'('出栈

            }
            else//若字符是二目操作符,则做以下操作
            {
                int thisPri = getPri(ch);  //获取操作符的优先级
                char prevOpt = st.top();  //获取栈顶操作符
                int prevPri = getPri(prevOpt); //获取栈顶操作符的优先级
                while (thisPri <= prevPri)//比较两者的优先级，若栈顶操作符的优先级高，则将栈顶操作符放进后缀表达式，并将其出栈
                {
                    post[j++] = prevOpt;//将栈顶操作符放进后缀表达式
                    st.pop();  //将其出栈
                    prevOpt = st.top();//取栈中新栈顶的操作符
                    prevPri = getPri(prevOpt);//同理获取栈中新栈顶的操作符的优先级
                }
                st.push(ch);  //把新的操作符进栈
            }
            i++;
        }
    }

    char ch = st.top();
    while (ch != '@')
    {
        post[j++] = ch;
        st.pop();
        ch = st.top();
    }//当栈底元素不是’@‘时，将栈顶元素放进后缀表达时的字符数组
    post[j] = '\0';
}
//读取数据，将后缀表达式的字符数字转变为数
double readNumber(char *dest, int *i)
{
    double x = 0;
    int num = 0;
    int j;
    while (dest[*i]<'0' || dest[*i]>'9')
        (*i)++;
    while (dest[*i] >= '0'&&dest[*i] <= '9')
    {
        x = x * 10 + (dest[*i] - '0');
        (*i)++;
    }
    if (dest[*i] == '.')//遇到小数点，则计算后面的数字个数，用于判断要把数字除以多少个10
    {
        (*i)++;
        while (dest[*i] >= '0'&&dest[*i] <= '9')
        {
            num++;
            x = x * 10 + (dest[*i] - '0');
            (*i)++;
        }
    }
    for (j = 0; j < num; j++)
        x = x / 10;
    return x;
}

//计算没有未知数的表达式
double getPAnswer(char *dest)
{
    double x[50];//创建一个数组，用于存放数据
    int len = 0;
    int i = 0;
    while (dest[i] != '\0')//当字符数组中的字符不是'\0'时
    {
        if (dest[i] >= '0'&&dest[i] <= '9')//遇到数字时
            x[len++] = readNumber(dest, &i);//调用读取数据函数，并且把i的地址传过去，这样i的值将会在函数调用后，也改变，从而使i跳到下一个类型的字符
        else if (isChar(dest[i]) || isOpr(dest[i]))//假设字符是二目操作符，或者是函数名缩写，则进行计算
        {
            switch (dest[i])
            {
            case '+'://加法
                x[len - 2] = x[len - 2] + x[len - 1];
                len--;
                i++;
                break;
            case '-'://加法
                x[len - 2] = x[len - 2] - x[len - 1];
                len--;
                i++;
                break;
            case '*'://乘法
                x[len - 2] = x[len - 2] * x[len - 1];
                len--;
                i++;
                break;
            case '/'://除法
                x[len - 2] = x[len - 2] / x[len - 1];
                len--;
                i++;
                break;
            case '^'://幂运算
                x[len - 2] = qPow(x[len - 2], x[len - 1]);
                len--;
                i++;
                break;
            case 's'://sin函数
                x[len - 1] = sin(x[len - 1]);
                i++;
                break;
            case 'c'://cos函数
                x[len - 1] = cos(x[len - 1]);
                i++;
                break;
            case 't'://tan函数
                x[len - 1] = tan(x[len - 1]);
                i++;
                break;
            case 'a'://abs函数
                x[len - 1] = abs(x[len - 1]);
                i++;
                break;
            case 'q'://开方函数
                x[len - 1] = sqrt(x[len - 1]);
                i++;
                break;
            case 'l'://ln函数
                x[len - 1] = log(x[len - 1]);
                i++;
                break;
            case 'g'://log10函数
                x[len - 1] = log10(x[len - 1]);
                i++;
                break;
            case 'u'://ceil函数
                x[len - 1] = ceil(x[len - 1]);
                i++;
                break;
            case 'd'://floor函数
                x[len - 1] = floor(x[len - 1]);
                i++;
                break;
            case 'i'://asin函数
                x[len - 1] = asin(x[len - 1]);
                i++;
                break;
            case 'j'://acos函数
                x[len - 1] = acos(x[len - 1]);
                i++;
                break;
            case 'k'://atan函数
                x[len - 1] = atan(x[len - 1]);
                i++;
                break;
            case 'm'://RtoD函数
                x[len - 1] = RtoD(x[len - 1]);
                i++;
                break;
            case 'n'://DtoR函数
                x[len - 1] = DtoR(x[len - 1]);
                i++;
                break;
            case 'r'://rec函数
                x[len - 1] = rec(x[len - 1]);
                i++;
                break;
            case 'w'://sqrt函数
                x[len - 1] = sqrt(x[len - 1]);
                i++;
                break;
            case 'p'://pos函数
                x[len - 1] = plusorminus(x[len - 1]);
                i++;
                break;
            }
        }
        else i++;
    }
    return x[len - 1];
}

double cmleval1(QStringList Sl) {
    char infix[max];//创建一个字符数组，用于存放中缀表达式
    char postfix[max];//创建一个字符数组，用于存放后缀表达式
    int i = 0;
    for(;i<Sl.size();)
    {
        char*  ch;
        QByteArray ba = Sl.at(i).toLatin1(); // must
        ch=ba.data();
        infix[i++]=*ch;
    }
    infix[i++] = '#';//放进一个标志字符，便于判断中缀表达式是否已查完
    infix[i] = '\0';
    getPostFix(infix, postfix);//调用中缀转后缀函数
    double a;//用于存放答案
    a = getPAnswer(postfix);//调用不含未知量的计算函数
    return a;//返回答案
    getchar();
}

#endif // CMLEVAL_H
