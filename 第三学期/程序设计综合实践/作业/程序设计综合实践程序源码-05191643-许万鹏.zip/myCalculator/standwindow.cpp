#include "standwindow.h"
#include "ui_standwindow.h"

standwindow::standwindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::standwindow)
{
    ui->setupUi(this);
}

standwindow::~standwindow()
{
    delete ui;
}
