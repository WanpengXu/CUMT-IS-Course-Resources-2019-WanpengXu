#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QDialog>
#include "about.h"
#include "rate.h"
#include "r2r.h"
#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_btn_0_clicked();

    void on_btn_1_clicked();

    void on_btn_2_clicked();

    void on_btn_3_clicked();

    void on_btn_4_clicked();

    void on_btn_5_clicked();

    void on_btn_6_clicked();

    void on_btn_7_clicked();

    void on_btn_8_clicked();

    void on_btn_9_clicked();

    void on_btn_point_clicked();

    void on_btn_add_clicked();

    void on_btn_sub_clicked();

    void on_btn_multi_clicked();

    void on_btn_div_clicked();

    void on_btn_equal_clicked();

    void on_btn_backspace_clicked();

    void on_btn_clear_clicked();

    void on_btn_clear_entry_clicked();

    void on_btn_percent_clicked();

    void on_btn_reciprocal_clicked();

    void on_btn_square_clicked();

    void on_btn_sqrt_clicked();

    void on_btn_leftbracket_clicked();

    void on_btn_rightbracket_clicked();

    void on_btn_sin_clicked();

    void on_btn_cos_clicked();

    void on_btn_ln_clicked();

    void on_btn_log_clicked();

    void on_btn_pi_clicked();

    void on_btn_e_clicked();

    void on_btn_tan_clicked();

    void on_btn_abs_clicked();

    void on_btn_ceil_clicked();

    void on_btn_floor_clicked();

    void on_btn_asin_clicked();

    void on_btn_acos_clicked();

    void on_btn_atan_clicked();

    void on_btn_rtd_clicked();

    void on_btn_dtr_clicked();

    void on_btn_square_root_clicked();

    void on_act_about_triggered();

    void on_act_rate_triggered();

    void on_act_xyz_triggered();

    void on_btn_pos_clicked();

private:
    Ui::MainWindow *ui;
    about ab;
    rate ra;
    xyz xy;
    double num1,num2,result;
    int mark;
    char symbol,flag;
    QString S,Snum1,Snum2,Seval;
    QStringList Sl;
};
#endif // MAINWINDOW_H
