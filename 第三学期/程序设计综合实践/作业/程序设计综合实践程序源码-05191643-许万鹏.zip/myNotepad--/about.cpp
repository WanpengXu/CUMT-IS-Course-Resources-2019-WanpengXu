#include "about.h"
#include "ui_about.h"

#include <QtWidgets>

About::About(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::About)
{
    ui->setupUi(this);

    setWindowIcon(QIcon(":/icon/easyicon_202101041042219846/1232018.png"));
}

About::~About()
{
    delete ui;
}
