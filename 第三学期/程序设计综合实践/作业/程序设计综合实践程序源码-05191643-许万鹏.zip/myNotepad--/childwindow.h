#ifndef CHILDWINDOW_H
#define CHILDWINDOW_H

#include <QTextEdit>
#include <QPrinter>

class childwindow:public QTextEdit
{
    Q_OBJECT
public:
    childwindow();
    void newFile();
    QString userFriendlyCurrentFile();
    QString currentFile() { return curFile; }
    bool loadFile(const QString &fileName);
    bool save();
    bool saveAs();
    void fontFormat(const QTextCharFormat &format);
    void setStyle(int style);
protected:
    void closeEvent(QCloseEvent *event);
private slots:
    void documentWasModified();
private:
    void setCurrentFile(const QString &fileName);
    QString strippedName(const QString &fullFileName);
    QString curFile;
    bool isUntitled;

    bool saveFile(QString fileName);

    bool wonSave();
};

#endif // CHILDWINDOW_H
