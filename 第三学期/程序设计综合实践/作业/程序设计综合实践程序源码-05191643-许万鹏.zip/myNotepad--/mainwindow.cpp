#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QtWidgets>
#include "childwindow.h"

#include <QLineEdit>
#include <QDialog>
#include <QPushButton>
#include <qDebug>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    mdiArea = new QMdiArea;
    mdiArea->setHorizontalScrollBarPolicy(Qt::ScrollBarAsNeeded);
    mdiArea->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
    setCentralWidget(mdiArea);

    createToolBars();
    setWindowIcon(QIcon(":/icon/easyicon_202101041050186922/1169007.png"));
    //move(200,150);
    //resize(800,500);
    //setWindowTitle(tr("多文档编辑器"));

    findDlg = new QDialog(this);
    findDlg->setWindowTitle(tr("查找&替换"));

    findLineEdit = new QLineEdit(findDlg);
    replaceLineEdit = new QLineEdit(findDlg);
    QPushButton *btn= new QPushButton(tr("查找下一个"), findDlg);
    QPushButton *btn2= new QPushButton(tr("替换"), findDlg);

    QVBoxLayout *layout= new QVBoxLayout(findDlg);
    QHBoxLayout *cldlayout0=new QHBoxLayout();
    QHBoxLayout *cldlayout1=new QHBoxLayout();
    QHBoxLayout *cldlayout2=new QHBoxLayout();
    qbtg1 = new QButtonGroup(this);
    qbtg2 = new QButtonGroup(this);
    qbtg3 = new QButtonGroup(this);

    QRadioButton *Button01 = new QRadioButton(this);
    Button01->setText(tr("非大小写匹配"));
    cldlayout0->addWidget(Button01);
    QRadioButton *Button02 = new QRadioButton(this);
    Button02->setText(tr("大小写匹配"));
    cldlayout0->addWidget(Button02);

    qbtg1->addButton(Button01);
    qbtg1->addButton(Button02);
    qbtg1->setId(Button01, 0);
    qbtg1->setId(Button02, 1);
    Button01->setChecked(true);

    QRadioButton *Button11 = new QRadioButton(this);
    Button11->setText(tr("单字匹配"));
    cldlayout1->addWidget(Button11);
    QRadioButton *Button12 = new QRadioButton(this);
    Button12->setText(tr("全字匹配"));
    cldlayout1->addWidget(Button12);

    qbtg2->addButton(Button11);
    qbtg2->addButton(Button12);
    qbtg2->setId(Button11, 0);
    qbtg2->setId(Button12, 1);
    Button11->setChecked(true);

    QRadioButton *Button21 = new QRadioButton(this);
    Button21->setText(tr("单个替换"));
    cldlayout2->addWidget(Button21);
    QRadioButton *Button22 = new QRadioButton(this);
    Button22->setText(tr("全部替换"));
    cldlayout2->addWidget(Button22);

    qbtg3->addButton(Button21);
    qbtg3->addButton(Button22);
    qbtg3->setId(Button21, 0);
    qbtg3->setId(Button22, 1);
    Button21->setChecked(true);

    layout->addLayout(cldlayout0);
    layout->addLayout(cldlayout1);
    layout->addWidget(findLineEdit);
    layout->addWidget(btn);
    layout->addLayout(cldlayout2);
    layout->addWidget(replaceLineEdit);
    layout->addWidget(btn2);

    connect(btn, SIGNAL(clicked()), this, SLOT(showFindText()));
    connect(btn2, SIGNAL(clicked()), this, SLOT(replaceText()));
}

MainWindow::~MainWindow()
{
    delete ui;
}

childwindow *MainWindow::createChildWindow()
{
    childwindow *child=new childwindow;
    mdiArea->addSubWindow(child);
    return child;
}

void MainWindow::on_action_newFile_triggered()
{
    childwindow *child=createChildWindow();
    child->newFile();
    child->show();
    enabledText();
}
void MainWindow::createToolBars()
{
    addToolBarBreak(Qt::TopToolBarArea);
    comboToolBar = addToolBar(tr("组合选择"));
    comboStyle = new QComboBox();
    comboToolBar->addWidget(comboStyle);//加入combox
    comboStyle->addItem("标准");
    comboStyle->addItem("项目符号 (●)");
    comboStyle->addItem("项目符号 (○)");
    comboStyle->addItem("项目符号 (■)");
    comboStyle->addItem("编号 (⒈⒉⒊)");
    comboStyle->addItem("编号 ( a.b.c.)");
    comboStyle->addItem("编号 ( A.B.C.)");
    comboStyle->addItem("编号 (ⅰ.ⅱ.ⅲ.)");
    comboStyle->addItem("编号 (Ⅰ.Ⅱ.Ⅲ.)");
    comboStyle->setStatusTip("段落加标号或编号");
    connect(comboStyle, SIGNAL(activated(int)), this, SLOT(textStyle(int)));

    comboFont = new QFontComboBox();
    comboToolBar->addWidget(comboFont);
    comboFont->setStatusTip("更改字体");
    connect(comboFont, SIGNAL(activated(QString)), this, SLOT(textFamily(QString)));

    comboSize = new QComboBox();
    comboToolBar->addWidget(comboSize);
    comboSize->setEditable(true);
    comboSize->setStatusTip("更改字号");

    QFontDatabase db;
    foreach(int size, db.standardSizes())
        comboSize->addItem(QString::number(size));

    connect(comboSize, SIGNAL(activated(QString)), this, SLOT(textSize(QString)));
    comboSize->setCurrentIndex(comboSize->findText(QString::number(QApplication::font().pointSize())));
}

void MainWindow::enabledText()
{

}

void MainWindow::updateMenus()
{

}
void MainWindow::on_action_open_triggered()
{
    QString fileName = QFileDialog::getOpenFileName(this, tr("打开"),QString(), tr("HTML 文档 (*.htm *.html);;所有文件 (*.*)"));
    if (!fileName.isEmpty()) {
        QMdiSubWindow *existing = findChildWindow(fileName);
        if (existing) {
            mdiArea->setActiveSubWindow(existing);
            return;
        }
        childwindow *child = createChildWindow();
        if (child->loadFile(fileName)) {
            statusBar()->showMessage(tr("文件已载入"), 2000);
            child->show();
        } else {
            child->close();
        }
    }
}
QMdiSubWindow *MainWindow::findChildWindow(const QString &fileName)
{
    QString canonicalFilePath = QFileInfo(fileName).canonicalFilePath();

    foreach (QMdiSubWindow *window, mdiArea->subWindowList()) {
        childwindow *childWindow = qobject_cast<childwindow *>(window->widget());
        if (childWindow->currentFile() == canonicalFilePath)
            return window;
    }
    return 0;
}

childwindow *MainWindow::activeChildWindow()
{
    if (QMdiSubWindow *activeSubWindow = mdiArea->activeSubWindow())
        return qobject_cast<childwindow *>(activeSubWindow->widget());
    return 0;
}

void MainWindow::on_action_save_triggered()
{
    if(activeChildWindow()&&activeChildWindow()->save())
        statusBar()->showMessage(tr("保存成功"),2000);
}

void MainWindow::on_action_saveAs_triggered()
{
    if(activeChildWindow()&&activeChildWindow()->saveAs())
        statusBar()->showMessage(tr("保存成功"),2000);
}

void MainWindow::on_action_close_triggered()
{
    close();
}

void MainWindow::on_action_undo_triggered()
{
    if(activeChildWindow())
        activeChildWindow()->undo();
}

void MainWindow::on_action_redo_triggered()
{
    if(activeChildWindow())
        activeChildWindow()->redo();
}

void MainWindow::on_action_cut_triggered()
{
    if(activeChildWindow())
        activeChildWindow()->cut();
}

void MainWindow::on_action_copy_triggered()
{
    if(activeChildWindow())
            activeChildWindow()->copy();
}

void MainWindow::on_action_paste_triggered()
{
    if(activeChildWindow())
            activeChildWindow()->paste();
}

void MainWindow::on_action_bold_triggered()
{
    QTextCharFormat fmt;
    fmt.setFontWeight(isBold?QFont::Bold:QFont::Normal);
    isBold=isBold?false:true;
    if(activeChildWindow())
        activeChildWindow()->fontFormat(fmt);
}

void MainWindow::on_action_italic_triggered()
{
    QTextCharFormat fmt;
    fmt.setFontItalic(isItalic);
    isItalic=isItalic?false:true;
    if(activeChildWindow())
        activeChildWindow()->fontFormat(fmt);
}

void MainWindow::on_action_underline_triggered()
{
    QTextCharFormat fmt;
    fmt.setFontUnderline(isUnderline);
    isUnderline=isUnderline?false:true;
    if(activeChildWindow())
        activeChildWindow()->fontFormat(fmt);
}

void MainWindow::textFamily(const QString &f)
{
    QTextCharFormat fmt;
    fmt.setFontFamily(f);
    if(activeChildWindow())
        activeChildWindow()->fontFormat(fmt);
}

void MainWindow::textSize(const QString &p)
{
    qreal pointSize = p.toFloat();
    if (p.toFloat() > 0) {
        QTextCharFormat fmt;
        fmt.setFontPointSize(pointSize);
        if(activeChildWindow())
            activeChildWindow()->fontFormat(fmt);
    }
}

void MainWindow::on_action_left_triggered()
{
    activeChildWindow()->setAlignment(Qt::AlignLeft | Qt::AlignAbsolute);
}

void MainWindow::on_action_mid_triggered()
{
    activeChildWindow()->setAlignment(Qt::AlignHCenter);
}

void MainWindow::on_action_right_triggered()
{
    activeChildWindow()->setAlignment(Qt::AlignRight | Qt::AlignAbsolute);
}

void MainWindow::on_action_color_triggered()
{
    if(activeChildWindow())
    {
        QColor col = QColorDialog::getColor(activeChildWindow()->textColor(), this);
        if (!col.isValid())
            return;
        QTextCharFormat fmt;
        fmt.setForeground(col);
        activeChildWindow()->fontFormat(fmt);
        //colorChanged(col);
    }
}

void MainWindow::textStyle(int styleIndex)
{
    if(activeChildWindow())
    {
        activeChildWindow()->setStyle(styleIndex);
    }
}

void MainWindow::on_action_print_triggered()
{
    if(activeChildWindow()){
    QPrinter printer(QPrinter::HighResolution);
    QPrintDialog *dlg = new QPrintDialog(&printer, this);
    if (activeChildWindow()->textCursor().hasSelection())
        dlg->addEnabledOption(QAbstractPrintDialog::PrintSelection);
    dlg->setWindowTitle(tr("打印文档"));
    if (dlg->exec() == QDialog::Accepted)
        activeChildWindow()->print(&printer);
    delete dlg;
    }
}

void MainWindow::on_action_printpreview_triggered()
{
    if(activeChildWindow()){
        QPrinter printer(QPrinter::HighResolution);
        QPrintPreviewDialog preview(&printer, this);
        connect(&preview, SIGNAL(paintRequested(QPrinter*)), SLOT(printPreview(QPrinter*)));
        preview.exec();
    }
}

void MainWindow::printPreview(QPrinter *printer)
{
    activeChildWindow()->print(printer);
}

void MainWindow::showFindText()
{
    if(!findstr)
    {
        activeChildWindow()->moveCursor(QTextCursor::Start);
        findstr=true;
    }
    int a = qbtg1->checkedId();
    int b = qbtg2->checkedId();
    QString str = findLineEdit->text();
    if(activeChildWindow())
        {
        switch (a)
        {
        case 0:
        {
            switch (b)
            {
            case 0:
            {
                qDebug()<<"00";
                if (!activeChildWindow()->find(str))
                {
                   QMessageBox::warning(this, tr("查找"),
                            tr("找不到%1").arg(str));
                }
                break;
            }
            case 1:
            {
                qDebug()<<"01";
                if (!activeChildWindow()->find(str,QTextDocument::FindWholeWords))
                {
                   QMessageBox::warning(this, tr("查找"),
                            tr("找不到%1").arg(str));
                }
                break;
            }
            }
            break;
        }
        case 1:
            {
                switch (b)
                {
                case 0:
                {
                    qDebug()<<"10";
                    if (!activeChildWindow()->find(str,QTextDocument::FindCaseSensitively))
                    {
                       QMessageBox::warning(this, tr("查找"),
                                tr("找不到%1").arg(str));
                    }
                    break;
                }
                case 1:
                {
                    qDebug()<<"11";
                    if (!activeChildWindow()->find(str,QTextDocument::FindCaseSensitively|QTextDocument::FindWholeWords))
                    {
                       QMessageBox::warning(this, tr("查找"),
                                tr("找不到%1").arg(str));
                    }
                    break;
                }
                }
             break;
            }
        }

        }
}

void MainWindow::replaceText()
{
    if(!replacestr)
    {
        activeChildWindow()->moveCursor(QTextCursor::Start);
        replacestr=true;
    }
    int c = qbtg3->checkedId();
    QString str = findLineEdit->text();
    QString str2=replaceLineEdit->text();

    if(activeChildWindow())
        {
        switch (c) {
        case 0:
        {
            if (!activeChildWindow()->find(str))
            {
               QMessageBox::warning(this, tr("替换"),
                        tr("不存在%1").arg(str));
            }
            else
            {
                //activeChildWindow()->moveCursor(QTextCursor::WordLeft);
                activeChildWindow()->insertPlainText(str2);
            }
            break;
        }
        case 1:
        {
            while(activeChildWindow()->find(str))
                activeChildWindow()->insertPlainText(str2);
            break;
        }
        }
    }
}

void MainWindow::on_action_tileHorizontal_triggered()
{
    mdiArea->tileSubWindows();
}

void MainWindow::on_action_windowLayer_triggered()
{
    mdiArea->cascadeSubWindows();
}

void MainWindow::on_action_closeallwd_triggered()
{
    mdiArea->closeAllSubWindows();
}

void MainWindow::on_action_closewd_triggered()
{
    mdiArea->closeActiveSubWindow();
}

void MainWindow::on_action_about_triggered()
{
    ab.show();
}

void MainWindow::on_action_find_triggered()
{
    //activeChildWindow()->moveCursor(QTextCursor::Start);
    findstr=false;
    replacestr=false;
    findDlg->show();
}
