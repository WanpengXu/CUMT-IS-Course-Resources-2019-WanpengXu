#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QPrintDialog>
#include <QPrinter>
#include <QPrintPreviewDialog>
#include <QPushButton>

#include "about.h"

class QMdiArea;
class childwindow;
class QComboBox;
class QFontComboBox;
class QMdiSubWindow;

class QLineEdit;
class QDialog;

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    childwindow *createChildWindow();

private slots:
    void on_action_newFile_triggered();

    void updateMenus();

    void on_action_open_triggered();

    void on_action_save_triggered();

    void on_action_saveAs_triggered();

    void on_action_close_triggered();

    void on_action_undo_triggered();

    void on_action_redo_triggered();

    void on_action_cut_triggered();

    void on_action_copy_triggered();

    void on_action_paste_triggered();

    void on_action_bold_triggered();

    void on_action_italic_triggered();

    void on_action_underline_triggered();

    void textFamily(const QString &f);
    void textSize(const QString &p);
    void textStyle(int styleIndex);
    void printPreview(QPrinter *);
    void showFindText();
    void replaceText();

    void on_action_left_triggered();

    void on_action_mid_triggered();

    void on_action_right_triggered();

    void on_action_color_triggered();

    void on_action_print_triggered();

    void on_action_printpreview_triggered();

    void on_action_tileHorizontal_triggered();

    void on_action_windowLayer_triggered();

    void on_action_closeallwd_triggered();

    void on_action_closewd_triggered();

    void on_action_about_triggered();

    void on_action_find_triggered();

private:
    QMdiSubWindow *findChildWindow(const QString &fileName);
    void createToolBars();
    QToolBar *comboToolBar;
    QComboBox *comboStyle;      //子控件
    QFontComboBox *comboFont;   //子控件
    QComboBox *comboSize;       //子控件
    childwindow *activeChildWindow();


    void enabledText();

    Ui::MainWindow *ui;
    QMdiArea *mdiArea;
    About ab;

    QLineEdit *findLineEdit;
    QLineEdit *replaceLineEdit;
    QDialog *findDlg;

    QButtonGroup *qbtg1;
    QButtonGroup *qbtg2;
    QButtonGroup *qbtg3;
    bool isBold=true;
    bool isItalic=true;
    bool isUnderline=true;

    bool findstr=false;
    bool replacestr=false;

};
#endif // MAINWINDOW_H
