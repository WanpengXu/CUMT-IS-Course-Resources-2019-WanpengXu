#include "panel.h"
#include <QTime>
#include <QTimer>
#include <QDebug>
#include <QGuiApplication>
#include <QProcess>

Panel::Panel(QObject *parent) : QObject(parent)
{
    initRand();
    initGame();
}

void Panel::initGame() {
    memset(panel_, 0, sizeof(panel_));
    score_ = 0;
    higherTile_ = 0;
    addRandomTile();
    addRandomTile();
}

void Panel::print() const {
    qDebug() << endl;
    index_t x, y;
    for (y = 0; y < kSize; y++) {
        for (x = 0; x < kSize; x++) {
            qDebug() << panel_[x][y];
        }
        qDebug() << endl;
    }
    qDebug() << endl;
}

bool Panel::move(Directions direction) {
    bool success = false;

    int i;
    for(i = Up; i < direction; i++) {//转过去
        rotateToRight();
    }
    success = moveTilesUpwards();//始终对转好的矩阵向上移动
    for(i = direction; i <= Right; i++) {//转回来
        rotateToRight();
    }
    if (success) {
        addRandomTile();
        emit panelChangedAfterMovement();
    }

    if(win() || gameEnded()) {
        emit gameStatusChanged();
        return false;
    }

    return success;
}

bool Panel::moveTilesUpwards() {
    if (win() || gameEnded()) {
        return false;
    }
    bool success = false;
    index_t x;
    for (x = 0; x < kSize; x++) {
        success |= slide(panel_[x]);
    }
    return success;
}

bool Panel::moveUp() {
    return move(Up);
}

bool Panel::moveLeft() {
    return move(Left);
}

bool Panel::moveDown() {
    return move(Down);
}

bool Panel::moveRight() {
    return move(Right);
}

value_t Panel::get(const index_t x, const index_t y) const {
    return panel_[x][y];
}

score_t Panel::score() const {
    return score_;
}

void Panel::initRand() {
    auto time = QTime::currentTime();
    qsrand((uint) time.msec());
}

bool Panel::restart()
{
    qApp->quit();
    QProcess::startDetached(qApp->applicationFilePath(), QStringList());
    return true;
}

value_t Panel::nextTileValue() const {
    return ((qrand() % 10) / 9 + 1) * 2;
}

void Panel::addRandomTile() {
    index_t x, y;
    value_t list[kSize * kSize][2];
    value_t len = 0;
    value_t r;

    for(x = 0; x < kSize; x++) {//生成坐标数组
        for(y = 0; y < kSize; y++) {
            if(panel_[x][y] == 0) {
                list[len][0] = x;
                list[len][1] = y;
                len++;
            }
        }
    }

    if (len > 0) {
        r = qrand() % len;
        x = list[r][0];
        y = list[r][1];
        panel_[x][y] = nextTileValue();
    }
}

void Panel::rotateToRight() {//逆时针旋转90度
    index_t i, j;
    value_t tmp;
    for (i = 0; i < kSize / 2; i++) {
        for (j = i; j < kSize - i - 1; j++) {
            tmp                          = panel_[i][j];
            panel_[i][j]                 = panel_[j][kSize-i-1];
            panel_[j][kSize-i-1]         = panel_[kSize-i-1][kSize-j-1];
            panel_[kSize-i-1][kSize-j-1] = panel_[kSize-j-1][i];
            panel_[kSize-j-1][i]         = tmp;
        }
    }
}

bool Panel::slide(value_t array[kSize]) {
    bool success = false;
    index_t pos, target, stop = 0;
    value_t mergeValue;

    for (pos = 0; pos < kSize; pos++) {
        if (array[pos] != 0) {
            target = findTarget(array, pos, stop);
            if (target != pos) {
                // need to move (0) or merge (!0)
                if (array[target] != 0) {
                    stop = target + 1; // don't cascade merges
                    mergeValue = array[target] + array[pos];
                    score_ += mergeValue;
                    emit scoreChanged();
                    higherTile_ = higherTile_>mergeValue?higherTile_:mergeValue;//max(higherTile_, mergeValue);
                }
                array[target] += array[pos]; // merge or move (target is 0)
                array[pos] = 0;
                success = true;
            }
        }
    }

    return success;
}


index_t Panel::findTarget(value_t array[kSize], const index_t pos, const index_t stop) const {
    index_t target;
    if (pos == 0) {
        return pos;
    }
    for (target = pos - 1; target >= 0; target--) {
        if (array[target] != 0) {
            if (array[target] != array[pos]) {
                // unable to merge or move
                return target + 1;
            }
            // merge is possible
            return target;
        }
        else {
            if (target == stop) {
                return target;
            }
        }
    }
    return pos;
}

bool Panel::findPairDown() const {
    bool success = false;
    index_t x, y;
    for (x = 0; x < kSize; x++) {
        for (y = 0; y < kSize - 1; y++) {
            if (panel_[x][y] == panel_[x][y+1]) {
                return true;
            }
        }
    }

    return success;
}

value_t Panel::countEmpty() const {
    index_t x, y;
    value_t count = 0;
    for (x = 0; x < kSize; x++) {
        for (y = 0; y < kSize; y++) {
            if (panel_[x][y] == 0) {
                count++;
            }
        }
    }
    return count;
}

bool Panel::gameEnded() {
    bool ended = true;
    if (countEmpty() > 0) {
        return false;
    }
    if (findPairDown()) {
        return false;
    }
    rotateToRight();
    if (findPairDown()) {
        ended = false;
    }
    rotateToRight();
    rotateToRight();
    rotateToRight();
    return ended;
}

bool Panel::win() {
    return higherTile_ == kValueOfLastTile;
}

void Panel::initRandPub()
{
    initRand();
}

void Panel::initGamePub()
{
    initGame();
}

bool Panel::restartPub()
{
    initRandPub();
    initGamePub();
    return true;
    //return restart();
}
