#include "panelmod.h"
//#include <QElapsedTimer>

PanelMod::PanelMod(QObject *parent) : QAbstractListModel(parent)
{
    connect(&panel_, &Panel::panelChangedAfterMovement, this, &PanelMod::onDataChanged);
    connect(&panel_, &Panel::scoreChanged, this, &PanelMod::scoreChanged);
    connect(&panel_, &Panel::gameStatusChanged, this, &PanelMod::gameStatusChanged);
}

int PanelMod::rowCount(const QModelIndex &parent) const {
    Q_UNUSED(parent)

    return kSize * kSize;
}

QVariant PanelMod::data(const QModelIndex &index, int role) const {
    index_t x, y;
    if (index.row() < 0 || index.row() >= kSize * kSize) {
        return QVariant();
    }
    if (role == Qt::DisplayRole) {
        x = index.row() % kSize;
        y = index.row() / kSize;
        QString str = QString::number(panel_.get(x, y));
        return str;
    }
    return QVariant();
}

void PanelMod::moveUp() {
    panel_.moveUp();
}

void PanelMod::moveRight() {
    panel_.moveRight();
}

void PanelMod::moveDown() {
    panel_.moveDown();
}

void PanelMod::moveLeft() {
    panel_.moveLeft();
}

void PanelMod::onDataChanged() {
    emit dataChanged(createIndex(0, 0), createIndex(rowCount() - 1, 0));
}

int PanelMod::score() const {
    return panel_.score();
}

bool PanelMod::gameEnded() {
    return panel_.gameEnded();
}

bool PanelMod::win() {
    return panel_.win();
}

bool PanelMod::restart()
{

    /*QElapsedTimer t;
    t.start();
    while(t.elapsed()<100);*/
    panel_.restartPub();
    emit dataChanged(createIndex(0, 0), createIndex(rowCount() - 1, 0));
    emit scoreChanged();
    emit gameStatusChanged();
    return true;
}
