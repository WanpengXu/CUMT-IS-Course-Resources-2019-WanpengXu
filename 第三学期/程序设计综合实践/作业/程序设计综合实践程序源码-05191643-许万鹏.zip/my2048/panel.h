#ifndef PANEL_H
#define PANEL_H

#include <QObject>
#include <QStringList>

typedef signed char index_t;
typedef unsigned int value_t;
typedef unsigned long int score_t;
static const index_t kSize = 4;
static const value_t kValueOfLastTile = 2048;

class Panel:public QObject
{
    Q_OBJECT
public:
    Panel(QObject *parent = 0);
    void print() const;
    bool moveUp();
    bool moveRight();
    bool moveDown();
    bool moveLeft();
    value_t get(const index_t x, const index_t y) const;
    score_t score() const;
    bool gameEnded();
    bool win();

    void initRandPub();
    void initGamePub();
    bool restartPub();

signals:
    void panelChangedAfterMovement();
    void scoreChanged();
    void gameStatusChanged();

private:
    value_t panel_[kSize][kSize];
    score_t score_;
    value_t higherTile_;

    enum Directions {
        Up = 0,
        Left,
        Down,
        Right
    };

    void initGame();
    void initRand();
    bool restart();
    value_t nextTileValue() const;
    void addRandomTile();

    bool move(Directions direction);
    bool moveTilesUpwards();
    void waitAndAddTile();

    void rotateToRight();
    bool slide(value_t array[kSize]);
    index_t findTarget(value_t array[kSize], const index_t pos, const index_t stop) const;
    bool findPairDown() const;
    value_t countEmpty() const;

};

#endif // PANEL_H
