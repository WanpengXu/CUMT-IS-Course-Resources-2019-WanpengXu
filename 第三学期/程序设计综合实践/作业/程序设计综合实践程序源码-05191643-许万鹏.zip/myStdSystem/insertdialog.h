#ifndef INSERTDIALOG_H
#define INSERTDIALOG_H

#include <QDialog>
#include <QButtonGroup>

namespace Ui {
class insertDialog;
}

class insertDialog : public QDialog
{
    Q_OBJECT

public:
    explicit insertDialog(QWidget *parent = 0);
    ~insertDialog();

private slots:
    void on_insert_pushButton_clicked();

private:
    Ui::insertDialog *ui;
    QButtonGroup* qbtg1;
};

#endif // INSERTDIALOG_H
