﻿#include "updatedialog.h"
#include "ui_updatedialog.h"
#include "mainwindow.h"
#include <QSqlQuery>
updateDialog::updateDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::updateDialog)
{
    ui->setupUi(this);
}

updateDialog::~updateDialog()
{
    delete ui;
}

void updateDialog::on_update_pushButton_clicked()
{
    if(ui->number_lineEdit->text().isEmpty()        ||
       ui->numberchange_lineEdit->text().isEmpty()  ||
       ui->namechange_lineEdit->text().isEmpty()    ||
       ui->collegechange_lineEdit->text().isEmpty() ||
       ui->agechange_lineEdit->text().isEmpty()     ||
       ui->sexchange_lineEdit->text().isEmpty()){
        QMessageBox::information(this,"提示","请输入完整内容");
    }
    else{
        QString number = ui->number_lineEdit->text();
        QString namechange =ui->namechange_lineEdit->text();
        QString numberchange = ui->numberchange_lineEdit->text();
        QString collegechange = ui->collegechange_lineEdit->text();
        QString agechange =ui->agechange_lineEdit->text();
        QString sexchange =ui->sexchange_lineEdit->text();
        QString telchange =ui->sexchange_lineEdit->text();
        QString zhuzichange =ui->sexchange_lineEdit->text();
        QSqlQuery query;
        query.exec("select * from student");
        int t =0;
        while(query.next()){
            if(number == query.value(1)){
                t=1;
                break;
            }
        }
        if(t==1){
            QString update_student =
                    QString("update student set StudentName=\"%1\" ,StudentNumber = \"%2\","
                                             "StudentCollege =\"%3\" ,StudentAge =\"%4\",StudentSex  =\"%5\" where StudentNumber =\"%6\"")
                    .arg(namechange,numberchange,collegechange,agechange,sexchange,number,telchange,zhuzichange);
            qDebug()<<update_student;
            if(!query.exec(update_student)){
                QMessageBox::information(this,"失败","修改失败");
            }
            else{
                QMessageBox::information(this,"成功","修改成功");
            }
        }
        else
            QMessageBox::information(this,"失败","学号不存在");
    }
}

void updateDialog::on_close_pushButton_clicked()
{
    ui->number_lineEdit->clear();
    ui->numberchange_lineEdit->clear();
    ui->namechange_lineEdit->clear();
    ui->collegechange_lineEdit->clear();
    ui->agechange_lineEdit->clear();
    ui->sexchange_lineEdit->clear();

    close();
}
