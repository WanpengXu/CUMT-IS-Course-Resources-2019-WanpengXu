﻿#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include <QMainWindow>
#include <QString>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QtWidgets>
#include <QTimer>
#include "deletedialog.h"
#include "insertdialog.h"
#include "selectdialog.h"
#include "updatedialog.h"

#include <QFileDialog>

namespace Ui {
class MainWindow;
}

struct stdinformation
{
    QString name;
    QString number;
    QString  results;
};

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();


private slots:
    void on_change_pushButton_clicked();

    void on_add_pushButton_clicked();

    void on_delete_pushButton_clicked();

    void on_refer_pushButton_clicked();

    void tabletimeslot();

    void on_backup_pushButton_clicked();

    void on_recover_pushButto_clicked();

private:
    Ui::MainWindow *ui;
    QSqlDatabase db;
    QTimer *tabletime;
    deleteDialog student_delete;
    insertDialog student_insert;
    updateDialog student_update;
    selectDialog student_select;
    int t;

};

#endif // MAINWINDOW_H
