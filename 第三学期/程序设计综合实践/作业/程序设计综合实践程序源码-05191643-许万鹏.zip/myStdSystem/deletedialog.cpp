#include "deletedialog.h"
#include "ui_deletedialog.h"
#include "mainwindow.h"
#include <QSqlQuery>

deleteDialog::deleteDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::deleteDialog)
{
    ui->setupUi(this);
}

deleteDialog::~deleteDialog()
{
    delete ui;
}

void deleteDialog::on_delete_pushButton_clicked()
{
    if(ui->scanf_lineEdit->text().isEmpty()){
        QMessageBox::information(this,"提示","请输入内容");
    }
    else{
        if(ui->studentname_radioButton->isChecked()){
            QString student_name;
            student_name = ui->scanf_lineEdit->text();
            QSqlQuery query;
            query.exec("select * from student");
            int t =0;
            while(query.next()){
                if(student_name == query.value(0).toString()){
                    t= 1;
                    break;
                }
            }
            if(t == 1){
                QString delete_name = QString("delete from student where StudentName = \"%1\"").arg(student_name);
                qDebug()<<delete_name;
                if(query.exec(delete_name)){
                    QMessageBox::information(this,"成功","删除成功");
                }
                else{
                    QMessageBox::information(this,"失败","删除失败");
                }
            }
            else{
                QMessageBox::information(this,"提示","不存在的姓名");
            }
        }
        else if(ui->studentnumber_radioButton->isChecked()){
            QString student_number;
            student_number = ui->scanf_lineEdit->text();
            QSqlQuery query;
            query.exec("select * from student");
            int t =0;
            while(query.next()){
                if(student_number == query.value(1).toString()){
                    t= 1;
                    break;
                }
            }
            if( t== 1){
                QString delete_student = QString("delete from student where StudentNumber = \"%1\"").arg(student_number);
                if(query.exec(delete_student)){
                    QMessageBox::information(this,"成功","删除成功");
                }
                else{
                    QMessageBox::information(this,"失败","删除失败");
                }
            }
            else{
                QMessageBox::information(this,"提示","不存在的学号");
            }
        }
        else{
            QMessageBox::information(this,"提示","请选择姓名或学号");
        }
    }
}
