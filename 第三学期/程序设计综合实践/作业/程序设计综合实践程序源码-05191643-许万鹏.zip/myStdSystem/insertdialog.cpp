﻿#include "insertdialog.h"
#include "ui_insertdialog.h"
#include "mainwindow.h"
#include <QSqlQuery>

insertDialog::insertDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::insertDialog)
{
    ui->setupUi(this);
    qbtg1 = new QButtonGroup(this);
    qbtg1->addButton(ui->male_radioButton);
    qbtg1->addButton(ui->famale_radioButton);
    qbtg1->setId(ui->male_radioButton,1);
    qbtg1->setId(ui->famale_radioButton,0);
    ui->male_radioButton->setChecked(true);
}

insertDialog::~insertDialog()
{
    delete ui;
}

void insertDialog::on_insert_pushButton_clicked()
{
    if(ui->studentname_lineEdit->text().isEmpty()    ||
       ui->studentnumber_ineEdit->text().isEmpty()   ||
       ui->studentcollege_lineEdit->text().isEmpty() ||
       ui->studentage_lineEdit->text().isEmpty()     ){
        QMessageBox::information(this,"提示","请输入完整");
    }
    else{
        QString student_name    = ui->studentname_lineEdit->text();
        QString student_number  = ui->studentnumber_ineEdit->text();
        QString student_college = ui->studentcollege_lineEdit->text();
        QString student_age     = ui->studentage_lineEdit->text();
        QString student_sex;
        int rto=qbtg1->checkedId();
        switch (rto) {
        case 1:student_sex="男";break;
        case 0:student_sex="女";break;
        }
        //QString student_sex     = ui->studentsex_lineEdit->text();

        QSqlQuery query;
        int index_delete = 0;
        query.exec("select * from student");
        while(query.next()){
            if(student_number == query.value(1)){
                index_delete = 1;
                break;
            }
        }
        if(index_delete == 1){
            QMessageBox::information(this,"提示","学号已存在");
        }
        else{
            QString insert_student = QString("insert into student values(\"%1\",\"%2\",\"%3\",\"%4\",\"%5\")")
                    .arg(student_name,student_number,student_college,student_age,student_sex);
            qDebug()<<insert_student;
            if(query.exec(insert_student)){
                QMessageBox::information(this,"成功","插入成功");
            }
            else{
                QMessageBox::information(this,"失败","插入失败");
            }
        }
    }
    this->close();
}
