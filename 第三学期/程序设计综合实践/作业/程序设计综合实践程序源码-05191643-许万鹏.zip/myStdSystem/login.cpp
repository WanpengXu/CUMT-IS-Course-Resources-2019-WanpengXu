#include "login.h"
#include "ui_login.h"

Login::Login(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Login)
{
    ui->setupUi(this);
    ldb = QSqlDatabase::addDatabase("QSQLITE","l");
    ldb.setDatabaseName("login.db");
    if(ldb.open()){
        qDebug()<<"ldb打开成功";
    }
    QSqlQuery queryLogin(ldb);
    if(queryLogin.prepare("create table Login(Username VARCHAR(30),Password VARCHAR(30))")){
        qDebug()<<"创建成功";
    }
    ui->pwdLine->setEchoMode(QLineEdit::Password);
    ui->loginBtn->setFocus(); //设置默认焦点
    ui->loginBtn->setShortcut( QKeySequence::InsertParagraphSeparator ); //设置快捷键为键盘的“回车”键
    ui->loginBtn->setShortcut(Qt::Key_Enter); //设置快捷键为enter键
    ui->loginBtn->setShortcut(Qt::Key_Return); //设置快捷键为小键盘上的enter键
}

Login::~Login()
{
    delete ui;
}

void Login::on_loginBtn_clicked()
{
    QString user;
    QString pwd;
    user = ui->userLine->text();//获取用户名
    pwd = ui->pwdLine->text();//获取密码
    //判断用户名密码是否为空，为空则提示不能为空
    if(user=="")
        QMessageBox::warning(NULL,"","用户名不能为空");//第一个字符串是标题
    else if (pwd=="")
        QMessageBox::warning(NULL,"","密码不能为空");
    else {
        QString MD5;
        QByteArray str;
        str = QCryptographicHash::hash(pwd.toLatin1(),QCryptographicHash::Md5);
        MD5.append(str.toHex());
        QString S = QString("select * from Login where Username=\"%1\" and Password=\"%2\"").arg(user).arg(MD5);
        QSqlQuery queryLogin(ldb);
        queryLogin.exec(S);
        if(queryLogin.first()){//执行查询语句
            QMessageBox::information(NULL, "登陆成功", "登陆成功！！！", QMessageBox::Yes);
            ldb.close();
            accept();
        }
        else{
            QMessageBox::warning(NULL,"error","用户名或者密码错误！！");
            // 清空内容并定位光标
            ui->userLine->clear();
            ui->pwdLine->clear();
            ui->userLine->setFocus();//将光标定位到用户名输入框
        }
    }
}

void Login::on_registerBtn_clicked()
{
    QString user;
    QString pwd;
    user=ui->userLine->text();//获取输入的用户名和密码
    pwd=ui->pwdLine->text();
    if(user=="")//判断用户名和密码是否为空
        QMessageBox::warning(NULL,"","用户名不能为空");
    else if (pwd=="")
        QMessageBox::warning(NULL,"","密码不能为空");
    else{
        QString MD5;
        QByteArray str;
        str = QCryptographicHash::hash(pwd.toLatin1(),QCryptographicHash::Md5);
        MD5.append(str.toHex());
        QString i =QString("insert into Login values(\"%1\",\"%2\");").arg(user).arg(MD5);//插入一条信息到数据库的user_table表中
        QString s =QString("select * from Login where Username = \"%1\"").arg(user);//在user表中查询是否有存在的用户名
        QSqlQuery queryLogin(ldb);
        queryLogin.exec(s);
        if(queryLogin.first()){
            QMessageBox::warning(NULL,"ERROR","用户名重复");//如果用户名重复，则提示用户名重复
        }
        else if (queryLogin.exec(i)){//如果用户名不重复，添加数据进入数据库
            QMessageBox::information(NULL,"提示","注册成功！！",QMessageBox::Yes);
            ldb.close();
            accept();
        }
        else{
            QMessageBox::warning(NULL,"ERRORf","注册失败，请重试！！");
        }
    }

}

void Login::on_toolButton_clicked()
{
    QMessageBox::information(NULL,"关于","学生信息管理系统\n信息安全19-01班 许万鹏\n2048 01.2021.15.0\n© 2021 Wpp。保留所有权利。",QMessageBox::Yes);
}
