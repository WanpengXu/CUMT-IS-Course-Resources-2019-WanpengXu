﻿#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("my.db");
    if(db.open()){
        qDebug()<<"db打开成功";
    }
    QSqlQuery query;
    if(query.exec("create table student(StudentName VARCHAR(30),StudentNumber VARCHAR(30),"
               "StudentCollege VARCHAR(30),StudentAge VARCHAR(30),StudentSex VARCHAR(30))")){
        qDebug()<<"创建成功";
    }

    query.exec("select * from student");
    t=0;
    while(query.next()){
        ui->information_tableWidget->insertRow(t);
        t++;
    }

    tabletime = new QTimer(this);
    tabletime->start(2000);
    connect(tabletime,SIGNAL(timeout()),this,SLOT(tabletimeslot()));
    ui->information_tableWidget->setColumnWidth(0,110);
    ui->information_tableWidget->setColumnWidth(1,120);
    ui->information_tableWidget->setColumnWidth(2,300);
    ui->information_tableWidget->setColumnWidth(3,72);
    ui->information_tableWidget->setColumnWidth(4,72);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_change_pushButton_clicked()
{
    student_update.show();
}

void MainWindow::on_add_pushButton_clicked()
{
    int index_row = ui->information_tableWidget->rowCount();
    ui->information_tableWidget->setRowCount(index_row+1);
    student_insert.show();
}

void MainWindow::on_delete_pushButton_clicked()
{
    student_delete.show();
}

void MainWindow::on_refer_pushButton_clicked()
{
    student_select.show();
}

void MainWindow::tabletimeslot()
{
    ui->information_tableWidget->clearContents();
    //QString studentname,studentnumber,studentcollege,studentage,studentsex;
    QSqlQuery query;
    query.exec("select * from student");
    int t=0;
    while(query.next()){
        ui->information_tableWidget->setItem(t,0,new QTableWidgetItem(query.value(0).toString()));
        ui->information_tableWidget->setItem(t,1,new QTableWidgetItem(query.value(1).toString()));
        ui->information_tableWidget->setItem(t,2,new QTableWidgetItem(query.value(2).toString()));
        ui->information_tableWidget->setItem(t,3,new QTableWidgetItem(query.value(3).toString()));
        ui->information_tableWidget->setItem(t,4,new QTableWidgetItem(query.value(4).toString()));
        ui->information_tableWidget->setItem(t,5,new QTableWidgetItem(query.value(5).toString()));
        ui->information_tableWidget->setItem(t,6,new QTableWidgetItem(query.value(6).toString()));
        ui->information_tableWidget->setItem(t,7,new QTableWidgetItem(query.value(7).toString()));

        /*
        qDebug()<<query.value(0).toString()
                <<","<<query.value(1).toString()
                <<","<<query.value(2).toString()
                <<","<<query.value(3).toString()
                <<","<<query.value(4).toString();
        */
        t++;
    }
}

void MainWindow::on_backup_pushButton_clicked()
{
    QString dirpath = QFileDialog::getExistingDirectory(this, "选择目录", "./", QFileDialog::ShowDirsOnly);
    if (QFile::exists(dirpath+"/my.db"))
    {
        QFile::remove(dirpath+"/my.db");
    }

    QFile::copy("my.db",dirpath+"/my.db");
}

void MainWindow::on_recover_pushButto_clicked()
{
    QString curPath = QDir::currentPath();
    QString aFileName = QFileDialog::getOpenFileName(this,"选择文件","./","数据库文件(*.db);;全部文件(*.*);");

    if (QFile::exists(curPath+"/my.db"))
    {
        db.close();
        QFile::remove(curPath+"/my.db");
    }
    QFile::copy(aFileName,curPath+"/my.db");
    db.open();
}
