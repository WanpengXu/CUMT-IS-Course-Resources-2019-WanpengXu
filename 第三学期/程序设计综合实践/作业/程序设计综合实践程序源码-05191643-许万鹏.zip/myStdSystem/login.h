#ifndef LOGIN_H
#define LOGIN_H

#include <QDialog>
#include <QMessageBox>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <qDebug>

#include <QCryptographicHash>

namespace Ui {
class Login;
}

class Login : public QDialog
{
    Q_OBJECT

public:
    explicit Login(QWidget *parent = nullptr);
    ~Login();

private slots:
    void on_loginBtn_clicked();

    void on_registerBtn_clicked();

    void on_toolButton_clicked();

private:
    Ui::Login *ui;
    QSqlDatabase ldb;
};

#endif // LOGIN_H
