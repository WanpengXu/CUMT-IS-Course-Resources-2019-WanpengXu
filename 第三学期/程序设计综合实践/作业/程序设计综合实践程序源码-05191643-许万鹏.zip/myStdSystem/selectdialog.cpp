﻿#include "selectdialog.h"
#include "ui_selectdialog.h"
#include "mainwindow.h"
#include <QSqlQuery>

selectDialog::selectDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::selectDialog)
{
    ui->setupUi(this);
    ui->select_tableWidget->setColumnWidth(0,90);
    ui->select_tableWidget->setColumnWidth(1,120);
    ui->select_tableWidget->setColumnWidth(2,210);
    ui->select_tableWidget->setColumnWidth(3,72);
    ui->select_tableWidget->setColumnWidth(4,72);
}

selectDialog::~selectDialog()
{
    delete ui;
}

void selectDialog::on_select_pushButton_clicked()
{

    if(ui->scanf_lineEdit->text().isEmpty()){
        QMessageBox::information(NULL,"提示","请输入查找内容");
    }
    else{
        if(ui->studentname_radioButton->isChecked()){
            QString student_name = ui->scanf_lineEdit->text();
            QSqlQuery query;
            query.exec("select * from student");
            int t =0;
            int check =0;
            while(query.next()){
                if(query.value(0).toString()==student_name){
                    int index_row =ui->select_tableWidget->rowCount();
                    ui->select_tableWidget->setRowCount(index_row+1);
                    ui->select_tableWidget->setItem(t,0,new QTableWidgetItem(query.value(0).toString()));
                    ui->select_tableWidget->setItem(t,1,new QTableWidgetItem(query.value(1).toString()));
                    ui->select_tableWidget->setItem(t,2,new QTableWidgetItem(query.value(2).toString()));
                    ui->select_tableWidget->setItem(t,3,new QTableWidgetItem(query.value(3).toString()));
                    ui->select_tableWidget->setItem(t,4,new QTableWidgetItem(query.value(4).toString()));
                    ui->select_tableWidget->setItem(t,5,new QTableWidgetItem(query.value(5).toString()));
                    ui->select_tableWidget->setItem(t,6,new QTableWidgetItem(query.value(6).toString()));
                    ui->select_tableWidget->setItem(t,7,new QTableWidgetItem(query.value(7).toString()));
                    check =1;
                    qDebug()<<query.value(0).toString()
                            <<","<<query.value(1).toString()
                            <<","<<query.value(2).toString()
                            <<","<<query.value(3).toString()
                            <<","<<query.value(4).toString();
                }
                t++;
            }
            if(check !=1){
                QMessageBox::information(NULL,"提示","输入姓名不存在");
            }
        }
        else if(ui->studentnumber_radioButton->isChecked()){
            QString student_number = ui->scanf_lineEdit->text();
            QSqlQuery query;
            query.exec("select * from student");
            int t =0;
            int check =0;
            while(query.next()){
                if(query.value(1).toString()== student_number){
                    int index_row =ui->select_tableWidget->rowCount();
                    ui->select_tableWidget->setRowCount(index_row+1);
                    ui->select_tableWidget->setItem(t,0,new QTableWidgetItem(query.value(0).toString()));
                    ui->select_tableWidget->setItem(t,1,new QTableWidgetItem(query.value(1).toString()));
                    ui->select_tableWidget->setItem(t,2,new QTableWidgetItem(query.value(2).toString()));
                    ui->select_tableWidget->setItem(t,3,new QTableWidgetItem(query.value(3).toString()));
                    ui->select_tableWidget->setItem(t,4,new QTableWidgetItem(query.value(4).toString()));
                    ui->select_tableWidget->setItem(t,5,new QTableWidgetItem(query.value(5).toString()));
                    ui->select_tableWidget->setItem(t,6,new QTableWidgetItem(query.value(6).toString()));
                    ui->select_tableWidget->setItem(t,7,new QTableWidgetItem(query.value(7).toString()));
                    check =1;
                    qDebug()<<query.value(0).toString()
                            <<","<<query.value(1).toString()
                            <<","<<query.value(2).toString()
                            <<","<<query.value(3).toString()
                            <<","<<query.value(4).toString();
                }
                t++;
            }
            if(check!=1){
                QMessageBox::information(NULL,"提示","学号不存在");
            }
        }
        else{
            QMessageBox::information(NULL,"提示","请选择姓名或学号查询");
        }
    }
}

void selectDialog::on_pushButton_clicked()
{
    ui->select_tableWidget->clearContents();
    ui->scanf_lineEdit->clear();
    close();
}
