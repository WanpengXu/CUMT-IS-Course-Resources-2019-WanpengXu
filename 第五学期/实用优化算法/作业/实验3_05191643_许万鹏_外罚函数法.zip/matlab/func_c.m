function cx=func_c(x)
    %cx=x(1)^2-x(2);
    cx=x(1)+2*x(2)+x(3)-4;
end