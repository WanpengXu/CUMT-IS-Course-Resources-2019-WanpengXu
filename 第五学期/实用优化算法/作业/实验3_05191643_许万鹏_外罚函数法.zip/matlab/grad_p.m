function gpx=grad_p(x,sigma)
    gfx=grad_f(x);
    cx=func_c(x);
    gcx=grad_c(x);
    gpx=gfx+2*sigma*gcx*cx;
end