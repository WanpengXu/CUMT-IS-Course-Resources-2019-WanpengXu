function x_asterisk=FR_CG(x0,sigma)
    n=2;
    epsilon1=1e-3;
    
%     [x,y]=meshgrid(-2:0.01:3, -2:0.01:9);
%     %[x,y]=meshgrid(-2.5:0.01:2.5, -4:0.01:6);
%     z=(1-x).^2+2.*(y-x.^2).^2;
%     %z=x.^4/4+y.^2/2-x.*y+x-y;
%     v1=-0.1:0.3:4;
%     v=[v1'];
%     contour(x,y,z,v,'LineWidth',1)
%     hold on
    
    x_old=x0;
    f_old=func_p(x0,sigma);
    nabla_f_old=grad_p(x0,sigma);
    if norm(nabla_f_old)<=epsilon1
        f_run=0;
    else
        f_run=1;
    end
    beta=0;
    d=0;
    k=0;
    
%     plot(x_old(1),x_old(2),'*');
%     hold on
    
    while f_run==1
        d=-nabla_f_old+beta*d;
        alpha=golden_section(x_old,0,2,d);
        x_new=x_old+alpha*d;
        f_new=func_p(x_new,sigma);
        nabla_f_new=grad_p(x_new,sigma);
        
%         lx=[x_old(1) x_new(1)];
%         ly=[x_old(2) x_new(2)];
%         line(lx,ly,'LineWidth',2,'Color','r'); hold on
%         plot(x_new(1),x_new(2),'r-*');hold on
        
        if norm(nabla_f_new)<=epsilon1
            f_run=0;
            x_old=x_new;
        else
            if rem(k,n)==0
                beta=0;
            else
                %beta=norm(nabla_f_new)^2/norm(nabla_f_old)^2;
                beta=(nabla_f_new'*nabla_f_new)/(nabla_f_old'*nabla_f_old);
                x_old=x_new;
                f_old=f_new;
                nabla_f_old=nabla_f_new;
            end
            k=k+1;
        end
    end
    x_asterisk=x_old;
end