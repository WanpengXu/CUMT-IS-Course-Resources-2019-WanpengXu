function x_asterisk=SUMT(x0)
%     x=-.0:0.01:4;
%     y=-1.5:0.01:10;
%     [X,Y] = meshgrid(x,y);
%     z=(X-2).^4+(Y-2*X).^2;
%     v1=[0.5 1 1.58203125000000 1.94612690485356 2.5 3 5 8];
%     v=[v1 v1];
%     contour(X,Y,z,v,'Linewidth',2);
%     hold on
%     
%     xx=-.2:0.01:3.2;
%     yy=xx.^2;
%     plot(xx,yy,'LineWidth',2,'Color','r');
%     hold on
    
    x_old=x0;
%     plot(x_old(1),x_old(2),'Marker','o','MarkerSize',10,'MarkerFaceColor','b');
%     hold on
%     x_pre=x_old;
%     pause
    
    sigma=10;
    c=10;
    epsilon=1e-5;
    f_stop=0;
    k=1;
    while f_stop==0
%         x_old=FR_CG(x_old,sigma);
        x_old=BFGS_quasiNewton(x_old,sigma);
        
%         lx=[x_pre(1) x_old(1)];
%         ly=[x_pre(2) x_old(2)];
%         line(lx,ly,'Color','r');
%         hold on
%         x_pre=x_old;
%         plot(x_pre(1),x_pre(2),'Marker','o','MarkerSize',10,'MarkerFaceColor','b');
%         hold on
        
        c_old=func_c(x_old);
        
        if norm(c_old,2)<epsilon
            f_stop=1;
        else
            sigma=sigma*10;
            k=k+1;
        end
    end
    x_asterisk=x_old
    f_asterisk=func_f(x_asterisk)
end