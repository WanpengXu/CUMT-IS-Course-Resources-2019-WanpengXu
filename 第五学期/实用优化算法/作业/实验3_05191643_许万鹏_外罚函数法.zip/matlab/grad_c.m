function gcx=grad_c(x)
    %gcx=[2*x(1);-1];
    gcx=[1;2;1];
end