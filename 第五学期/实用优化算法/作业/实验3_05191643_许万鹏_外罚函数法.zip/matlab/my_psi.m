function psi_x=my_psi(alpha,x,d)
    psi_x=func_f(x+alpha*d);
end