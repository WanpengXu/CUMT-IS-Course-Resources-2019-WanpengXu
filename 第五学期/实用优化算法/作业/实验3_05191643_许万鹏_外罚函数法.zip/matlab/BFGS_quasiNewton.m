function x_asterisk=BFGS_quasiNewton(x_old,sigma)
    epsilon=1e-5;
    r=1/4;
    p_old=func_p(x_old,sigma);
    grad_p_old=grad_p(x_old,sigma);
    H=eye(length(x_old));
    I=H;
    f_run=1;
    k=0;
    while f_run==1
        f_run2=1;
        alpha=1;
        d=-H*grad_p_old;
        while f_run2==1
            x_new=x_old+alpha*d;
            phi_new=func_p(x_new,sigma);
            gphi_new=grad_p(x_new,sigma);
            if p_old-phi_new>=-alpha*r*grad_p_old'*d
                f_run2=0;
                s=x_new-x_old;y=gphi_new-grad_p_old;
                x_old=x_new;
                p_old=phi_new;
                grad_p_old=gphi_new;
                H=(I-(s*y')/(s'*y))*H*(I-(y*s')/(s'*y))+(s*s')/(s'*y);
            else
                alpha=alpha/2;
            end
        end
        if norm(grad_p_old)<=epsilon
            f_run=0;
        end
        k=k+1;
    end
    x_asterisk=x_old;
end