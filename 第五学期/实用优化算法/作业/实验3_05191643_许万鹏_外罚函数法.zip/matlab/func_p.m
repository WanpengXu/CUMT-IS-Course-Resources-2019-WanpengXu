function px=func_p(x,sigma)
    fx=func_f(x);
    cx=func_c(x);
    px=fx+sigma*cx'*cx;
end