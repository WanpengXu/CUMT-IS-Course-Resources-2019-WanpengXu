function psi_x=my_psi(alpha,x,d)
    psi_x=func_a(x+alpha*d);
end