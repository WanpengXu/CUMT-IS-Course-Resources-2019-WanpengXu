function x_asterisk=golden_section(x,a,b,d)
    epsilon=1e-5;
    r=(sqrt(5)-1)/2;%0.618
    alpha1=a+(1-r)*(b-a);
    alpha2=a+r*(b-a);
    psi1=my_psi(alpha1,x,d);
    psi2=my_psi(alpha2,x,d);
    while abs(b-a)>=epsilon
        if psi1<=psi2
            b=alpha2;
            alpha2=alpha1;
            psi2=psi1;
            alpha1=a+(1-r)*(b-a);
            psi1=my_psi(alpha1,x,d);
        else
            a=alpha1;
            alpha1=alpha2;
            psi1=psi2;
            alpha2=a+r*(b-a);
            psi2=my_psi(alpha2,x,d);
        end
        x_asterisk=(a+b)/2;
    end
end