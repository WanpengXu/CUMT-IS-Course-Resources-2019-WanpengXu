﻿#include "Graphmtx.h"
#include <iostream>
using namespace std;

int main() {
    Graphmtx<char,int> Gra;
    cin >> Gra;
    //cout << Gra;
    char start;
    cout << endl << "请输入遍历起点：" << endl;
    cin >> start;
    cout << endl << "遍历路线为：" << endl;
    DFSTraverse(Gra,start);
    cout << endl;
    return 0;
}