#include "Graph.h"
#include <iostream>
using namespace std;

int main()
{
	char order;
	mainjiemian();
	while (cin >> order)
	{
		switch (order)
		{
		case'1':
		{
			system("cls");
			map();
			system("pause");
			system("cls");
			mainjiemian();
			break;
		}
		case'2':
		{
			system("cls");
			map();
			ShortestPath();
			system("pause");
			system("cls");
			mainjiemian();
			break;
		}
		case'3':
		{
			system("cls");
			map();
			find();
			system("pause");
			system("cls");
			mainjiemian();
			break;
		}
		case'4':
		{
			system("cls");
			map();
			xiugai();
			system("pause");
			system("cls");
			mainjiemian();
			break;
		}
		case'5':
		{
			system("cls");
			exit();
			return 0;
		}
		default:
		{
			cin.clear();
			cin.sync();
			cout << "����������·��������档" << endl;
			system("pause");
			system("cls");
			mainjiemian();
			break;
		}
		}
	}
}