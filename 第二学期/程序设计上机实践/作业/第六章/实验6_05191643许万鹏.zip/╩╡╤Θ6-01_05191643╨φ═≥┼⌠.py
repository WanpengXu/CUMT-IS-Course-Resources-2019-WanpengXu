f=open("sy6-1.txt","r")
content=f.read(-1)
print(content)
f.close()
