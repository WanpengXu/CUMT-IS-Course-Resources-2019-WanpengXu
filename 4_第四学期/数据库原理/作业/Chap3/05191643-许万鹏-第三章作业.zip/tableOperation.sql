-- 1
SELECT Title,BookID
FROM book
WHERE PublisherName='高等教育出版社';

-- 2
SELECT BookID,Title
FROM book
WHERE BookID IN(
	SELECT BookID
    FROM author
    WHERE Author='郭雨辰'
    );

-- 3
SELECT Title
FROM book
WHERE BookID IN(
	SELECT BookID
    FROM bookBorrow
    WHERE CardID IN(
		SELECT CardID
        FROM borrower
        WHERE Name='王丽'
        )
	);

-- 4
SELECT Title
FROM book
WHERE BookID IN(
	SELECT BookID
    FROM bookBorrow
    WHERE CardID IN(
		SELECT CardID
        FROM borrower
        WHERE Name='李明'
        ) AND
        DateOut BETWEEN 2018-1-1 AND 2018-6-30
	);

-- 5
CREATE VIEW unborrowedBook AS
SELECT BookID,Title
FROM book
WHERE BookID NOT IN(
	SELECT BookID
    FROM bookBorrow
    WHERE DateOut BETWEEN 2017-1-1 AND 2017-12-31
	);

-- 6
CREATE VIEW unreturnedBook AS
SELECT BookID,Title,Name,Phone
FROM book,bookBorrow,borrower
WHERE book.BookID=bookBorrow.BookID AND
		bookBorrow.CardID=borrower.CardID AND
        NOW()>DueOut;-- IsReturn IS FALSE;

-- 7
CREATE VIEW popBook AS
SELECT Title
FROM book,bookBorrow
WHERE book.BookID=bookBorrow.BookID
GROUP BY BookID
ORDER BY COUNT(CardID) DESC
LIMIT 10 OFFSET 0;

-- 8
INSERT INTO book(
	BookID,
    Title,
    PublisherName
    )
    VALUES(
    'TP319-201',
    '大数据',
    '广西师范大学出版社'
    );
INSERT INTO bookAuthor(
	BookID,
    Author
    )
    VALUES(
    'TP319-201',
    '涂子沛'
    );
    
-- 9
UPDATE publisher
SET Phone='010-64054588'
WHERE Name='高等教育出版社';

-- 10
DELETE
FROM book
WHERE BookID='D001701';
-- 创建表时已设置bookAuthor随book级联删除