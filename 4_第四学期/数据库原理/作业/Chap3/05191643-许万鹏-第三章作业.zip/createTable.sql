CREATE DATABASE Library;
USE Library;
CREATE TABLE publisher(
	Name CHAR(10),
	Address CHAR(40),
	Phone CHAR(12),
    
    PRIMARY KEY(Name)
	);
CREATE TABLE book(
	BookID CHAR(10),
	Title CHAR(20),
	PublisherName CHAR(10),

	PRIMARY KEY(BookID),
	FOREIGN KEY(PublisherName) REFERENCES publisher(Name)
	);
CREATE TABLE bookAuthor(
	BookID CHAR(10),
	Author CHAR(8),
	
    PRIMARY KEY(BookID,Author),
    FOREIGN KEY(BookID) REFERENCES book(BookID) ON DELETE CASCADE
	);
CREATE TABLE borrower(
	CardID CHAR(8),
	Name CHAR(8),
	Address CHAR(40),
	Phone CHAR(12),
       
	PRIMARY KEY(CardID)
	);
CREATE TABLE bookBorrow(
	BookID CHAR(10),
	CardID CHAR(8),
	DateOut DATETIME,
	DueOut DATETIME,
    IsReturn BOOL,
	
    PRIMARY KEY(BookID,CardID),
    FOREIGN KEY(BookID) REFERENCES book(BooKID),
	FOREIGN KEY(CardID) REFERENCES borrower(CardID)
	);